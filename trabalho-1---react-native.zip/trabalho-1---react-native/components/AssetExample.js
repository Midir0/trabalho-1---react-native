import * as React from 'react';
import { Text, View, StyleSheet, Image, TouchableOpacity } from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        Mobile Wallet
      </Text>
      <Image style={styles.logo} source={require('../assets/png.png')} />
      <TouchableOpacity style={styles.button} onPress={this.onPress}>
          <Text>Press Here</Text>
        </TouchableOpacity>
    </View>
    
    
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ea1d2c',
    padding: 4,
  },
  logo: {
    height: 200,
    width: 200,
  },
    paragraph: {
      margin: 50,
      fontSize: 30,
      color: '#ffffff',
  },
  button: {
    margin: 50,
    backgroundColor: '#ffffff',
  }
});
